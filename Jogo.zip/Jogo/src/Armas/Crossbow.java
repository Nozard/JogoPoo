package Armas;

public class Crossbow extends Weapons{
    
    public Crossbow(){
		super(15, 10, "balestra");
		// TODO Auto-generated constructor stub
	}

}