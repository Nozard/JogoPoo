package Armas;

public class Staff extends Weapons {

	public Staff() {
		super(13, 12, "cajado");
		
	}
    
}