package Armas;

public class Axe extends Weapons{

	public Axe() {
		super(17, 8, "Machado");
	}
    

}