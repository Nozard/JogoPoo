package Armas;

public class Sword extends Weapons{

	public Sword() {
		super(10, 15, "Espada");
	}

}