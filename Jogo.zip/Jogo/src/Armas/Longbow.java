package Armas;

public class Longbow extends Weapons {
    
    public Longbow() {
		super(12, 13, "Arco Longo");
    }
}