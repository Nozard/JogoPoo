package Armas;

public class Wand extends Weapons{

	public Wand() {
		super(16, 9, "Varinha");
		// TODO Auto-generated constructor stub
	}

    
	
}